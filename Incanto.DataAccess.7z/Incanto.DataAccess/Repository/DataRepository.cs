﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Incanto.DataAccess.Context;
using Incanto.DataAccess.Interfaces;
using Incanto.Domain.Base.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Incanto.DataAccess.Repository
{
	public class DataRepository<TEntity> : IDataRepository<TEntity>
		where TEntity : class, IBaseEntity, new()
	{
		public void Add(TEntity entity)
		{
			using (var context = new IncantoDataContext(new DbContextOptions<IncantoDataContext>()))
			{
				context.Set<TEntity>().Add(entity);
				context.SaveChanges();
			}
		}

		public void Update(TEntity entity)
		{
			using (var context = new IncantoDataContext(new DbContextOptions<IncantoDataContext>()))
			{
				context.Set<TEntity>().Attach(entity);
				context.Update(entity);
				context.SaveChanges();
			}
		}

		public void Detele(TEntity entity)
		{
			using (var context = new IncantoDataContext(new DbContextOptions<IncantoDataContext>()))
			{
				context.Set<TEntity>().Attach(entity);
				context.Remove(entity);
				context.SaveChanges();
			}
		}

		public void Detele(int id)
		{
			using (var context = new IncantoDataContext(new DbContextOptions<IncantoDataContext>()))
			{
				var entity = context.Set<TEntity>().Find(id);
				context.Set<TEntity>().Attach(entity);
				context.Remove(entity);
				context.SaveChanges();
			}
		}

		public List<TEntity> GetList(Expression<Func<TEntity, bool>> predicate = null)
		{
			using (var context = new IncantoDataContext(new DbContextOptions<IncantoDataContext>()))
			{
				IQueryable<TEntity> query = context.Set<TEntity>();
				if (predicate != null)
					query = query.Where(predicate);
				return query.ToList();
			}
		}

		public TEntity Get(Expression<Func<TEntity, bool>> predicate = null)
		{
			return GetList(predicate).FirstOrDefault();
		}
	}
}
